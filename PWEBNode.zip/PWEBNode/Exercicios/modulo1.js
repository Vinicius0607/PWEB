let texto = "Observe que essa mensagem vem do modulo";
module.exports = texto;