function formatarDataDisplay(isoDate) {
  if (!isoDate) return "-";
  const parts = isoDate.split("-");
  if (parts.length !== 3) return isoDate;
  return `${parts[2].padStart(2,"0")}/${parts[1].padStart(2,"0")}/${parts[0]}`;
}

let tarefas = JSON.parse(localStorage.getItem("tarefas")) || [];
const salvar = () => localStorage.setItem("tarefas", JSON.stringify(tarefas));
const gerarId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

const filtroPrioridade = document.getElementById("filtroPrioridade");
const filtroResponsavel = document.getElementById("filtroResponsavel");
const buscarTexto = document.getElementById("buscarTexto");
const limparFiltrosBtn = document.getElementById("limparFiltros");

function aplicarFiltros(t) {
  const pri = filtroPrioridade.value;
  if (pri !== "todos" && t.prioridade !== pri) return false;
  const respFilter = filtroResponsavel.value.trim().toLowerCase();
  if (respFilter && !t.responsavel.toLowerCase().includes(respFilter)) return false;
  const busca = buscarTexto.value.trim().toLowerCase();
  if (busca) {
    const combinado = (t.titulo + " " + (t.descricao||"")).toLowerCase();
    if (!combinado.includes(busca)) return false;
  }
  return true;
}

function renderizar() {
  document.querySelectorAll(".tarefas").forEach(div => (div.innerHTML = ""));

  tarefas.forEach(t => {
    if (!aplicarFiltros(t)) return; 

    const card = document.createElement("div");
    card.className = "tarefa prioridade-" + t.prioridade;
    card.dataset.id = t.id;

    const dataDisplay = formatarDataDisplay(t.vencimento);

    card.innerHTML = `
      <h4>${escapeHtml(t.titulo)}</h4>
      <p>${escapeHtml(t.descricao || "")}</p>
      <p><strong>Prioridade:</strong> ${t.prioridade}</p>
      <p><strong>Prazo:</strong> ${dataDisplay}</p>
      <p><strong>Responsável:</strong> ${escapeHtml(t.responsavel)}</p>
      <div>
        <button class="btn editar" onclick="abrirModal('${t.id}')">Editar</button>
        <button class="btn excluir" onclick="excluirTarefa('${t.id}')">Excluir</button>
      </div>`;
    const coluna = document.getElementById(t.status);
    if (coluna) coluna.appendChild(card);
  });

  salvar();
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

document.getElementById("task-form").addEventListener("submit", e => {
  e.preventDefault();
  const titulo = document.getElementById("titulo").value.trim();
  const descricao = document.getElementById("descricao").value.trim();
  const prioridade = document.getElementById("prioridade").value;
  const vencimento = document.getElementById("vencimento").value; 
  const responsavel = document.getElementById("responsavel").value.trim();

  if (!titulo || !vencimento || !responsavel) {
    alert("Preencha título, data e responsável!");
    return;
  }

  tarefas.push({
    id: gerarId(),
    titulo,
    descricao,
    prioridade,
    vencimento, 
    responsavel,
    status: "conteudo"
  });

  e.target.reset();
  renderizar();
});

function excluirTarefa(id) {
  if (confirm("Deseja realmente excluir esta tarefa?")) {
    tarefas = tarefas.filter(t => t.id !== id);
    renderizar();
  }
}

const modal = document.getElementById("modal");
let idEdit = null;

function abrirModal(id) {
  idEdit = id;
  const t = tarefas.find(x => x.id === id);
  if (!t) return;

  document.getElementById("editTitulo").value = t.titulo;
  document.getElementById("editDescricao").value = t.descricao || "";
  document.getElementById("editPrioridade").value = t.prioridade;
  document.getElementById("editVencimento").value = t.vencimento || "";
  document.getElementById("editResponsavel").value = t.responsavel;

  modal.style.display = "flex";
}

document.getElementById("cancelarEdicao").onclick = () => {
  modal.style.display = "none";
  idEdit = null;
};

document.getElementById("salvarEdicao").onclick = () => {
  if (!idEdit) return;
  const t = tarefas.find(x => x.id === idEdit);
  if (!t) return;

  const novoTitulo = document.getElementById("editTitulo").value.trim();
  const novaDesc = document.getElementById("editDescricao").value.trim();
  const novaPri = document.getElementById("editPrioridade").value;
  const novaVenc = document.getElementById("editVencimento").value;
  const novoResp = document.getElementById("editResponsavel").value.trim();

  if (!novoTitulo || !novaVenc || !novoResp) {
    alert("Preencha título, data e responsável!");
    return;
  }

  t.titulo = novoTitulo;
  t.descricao = novaDesc;
  t.prioridade = novaPri;
  t.vencimento = novaVenc; 
  t.responsavel = novoResp;

  modal.style.display = "none";
  idEdit = null;
  renderizar();
};

modal.addEventListener("click", (ev) => {
  if (ev.target === modal) {
    modal.style.display = "none";
    idEdit = null;
  }
});

["conteudo", "progresso", "concluido"].forEach(id => {
  Sortable.create(document.getElementById(id), {
    group: "kanban",
    animation: 150,

    onAdd: evt => {
      const idCard = evt.item.dataset.id;
      const tarefa = tarefas.find(t => t.id === idCard);
      if (tarefa) {
        tarefa.status = evt.to.id;
        salvar();
      }
    },

    onEnd: evt => {
      const idCard = evt.item.dataset.id;
      const tarefa = tarefas.find(t => t.id === idCard);
      if (tarefa) {
        tarefa.status = evt.to.id;
        salvar();
      }
    }
  });
});

const modoBtn = document.getElementById("modo-btn");
modoBtn.onclick = () => {
  document.body.classList.toggle("dark");
  const dark = document.body.classList.contains("dark");
  modoBtn.textContent = dark ? "☀️ Claro" : "🌙 Escuro";
  localStorage.setItem("modo", dark ? "dark" : "light");
};

if (localStorage.getItem("modo") === "dark") {
  document.body.classList.add("dark");
  modoBtn.textContent = "☀️ Claro";
}

[filtroPrioridade, filtroResponsavel, buscarTexto].forEach(el => {
  el.addEventListener("input", renderizar);
});

limparFiltrosBtn.addEventListener("click", () => {
  filtroPrioridade.value = "todos";
  filtroResponsavel.value = "";
  buscarTexto.value = "";
  renderizar();
});

renderizar();
